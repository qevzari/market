package dev.market;

import java.util.concurrent.ThreadLocalRandom;

/** An inclusive integer range such as "12-30". A single number ("5") is the range 5-5. */
public record Range(int min, int max) {

    public Range {
        if (min > max) {
            int t = min;
            min = max;
            max = t;
        }
    }

    /** Parses "12-30", "12 - 30" or "5". Returns null when the text isn't a valid range. */
    public static Range parse(String text) {
        if (text == null) {
            return null;
        }
        String s = text.trim().replace(",", "").replace(" ", "");
        if (s.isEmpty()) {
            return null;
        }
        try {
            String[] parts = s.split("-");
            if (parts.length == 1) {
                int v = Integer.parseInt(parts[0]);
                return new Range(v, v);
            }
            if (parts.length == 2) {
                return new Range(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
            }
        } catch (NumberFormatException ignored) {
            // fall through
        }
        return null;
    }

    /** A random value in [min, max], both ends included. */
    public int roll() {
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    @Override
    public String toString() {
        return min == max ? String.valueOf(min) : min + "-" + max;
    }
}
