package dev.market;

import org.bukkit.inventory.ItemStack;

/** One listing in the current rotation. */
public final class Offer {
    public final String id;
    /** A single unit of the item being sold (amount 1). */
    public final ItemStack item;
    /** Price per single item, in the configured currency. */
    public final int price;
    public int stock;
    public final boolean rare;

    public Offer(String id, ItemStack item, int price, int stock, boolean rare) {
        this.id = id;
        this.item = item;
        this.price = price;
        this.stock = stock;
        this.rare = rare;
    }
}
