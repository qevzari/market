package dev.market;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

public final class MarketCommand implements CommandExecutor, TabCompleter {

    private static final int MAX_VALUE = 1_000_000;

    private final MarketPlugin plugin;

    MarketCommand(MarketPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            open(s);
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "open" -> open(s);
            case "info", "time" -> info(s);
            case "list" -> list(s);
            case "set" -> {
                if (admin(s)) {
                    if (a.length < 4) {
                        usage(s);
                    } else {
                        setRange(s, a[1], a[2], a[3]);
                    }
                }
            }
            case "price", "items" -> {
                if (admin(s)) {
                    if (a.length < 3) {
                        usage(s);
                    } else {
                        setRange(s, sub, a[1], a[2]);
                    }
                }
            }
            case "add" -> {
                if (admin(s)) {
                    add(s, a);
                }
            }
            case "remove" -> {
                if (admin(s)) {
                    if (a.length < 2) {
                        usage(s);
                    } else {
                        remove(s, a[1]);
                    }
                }
            }
            case "reroll" -> {
                if (admin(s)) {
                    plugin.rotate(true);
                    plugin.msg(s, "<green>The market has been rotated.");
                }
            }
            case "reload" -> {
                if (admin(s)) {
                    plugin.loadSettings();
                    plugin.msg(s, "<green>Config reloaded <gray>(" + plugin.entries.size()
                            + " items). Current stock stays until the next rotation.");
                }
            }
            default -> usage(s);
        }
        return true;
    }

    // ───────────────────────── player commands ─────────────────────────

    private void open(CommandSender s) {
        if (!(s instanceof Player p)) {
            plugin.msg(s, "<red>Only players can open the market.");
            return;
        }
        if (!p.hasPermission("market.use")) {
            plugin.msg(s, "<red>You don't have permission to use the market.");
            return;
        }
        plugin.gui.open(p, true);
    }

    private void info(CommandSender s) {
        long left = plugin.nextRotation - System.currentTimeMillis();
        plugin.msg(s, "<yellow>Next rotation in <white>" + MarketPlugin.fmtTime(left)
                + "</white> <gray>(every " + plugin.rotationMinutes + " min)");
        if (plugin.offers.isEmpty()) {
            plugin.msg(s, "<gray>The market is empty right now.");
            return;
        }
        for (Offer o : plugin.offers) {
            plugin.msg(s, (o.rare ? "<light_purple>★ " : "<gray>• ") + "<white>"
                    + MarketPlugin.describe(o.item) + "</white> <dark_gray>|</dark_gray> <gold>"
                    + o.price + "x " + MarketPlugin.prettyItem(plugin.currency)
                    + "</gold> <dark_gray>|</dark_gray> <green>" + o.stock + " left");
        }
    }

    private void list(CommandSender s) {
        plugin.msg(s, "<yellow>Everything the market can sell:");
        for (Entry e : plugin.entries.values()) {
            String rare = e.isRare() ? " <light_purple>rare " + pct(e.chance) : "";
            plugin.msg(s, "<gray>• <white>" + MarketPlugin.pretty(e.id) + "</white> <dark_gray>|</dark_gray>"
                    + " price <gold>" + e.price + "</gold> <dark_gray>|</dark_gray>"
                    + " count <aqua>" + e.count + "</aqua>" + rare);
        }
    }

    private String pct(double chance) {
        return String.format(Locale.ROOT, "(%.1f%% per rotation)", chance * 100.0);
    }

    // ───────────────────────── admin commands ─────────────────────────

    private boolean admin(CommandSender s) {
        if (s.hasPermission("market.admin")) {
            return true;
        }
        plugin.msg(s, "<red>You need <white>market.admin</white> for that.");
        return false;
    }

    private void usage(CommandSender s) {
        plugin.msg(s, "<yellow>Market commands:");
        plugin.msg(s, "<gray>/market <dark_gray>- open the shop");
        plugin.msg(s, "<gray>/market info | list");
        if (s.hasPermission("market.admin")) {
            plugin.msg(s, "<gray>/market set price <item> <min>-<max>");
            plugin.msg(s, "<gray>/market items <item> <min>-<max> <dark_gray>(stock amount)");
            plugin.msg(s, "<gray>/market add <item> <min>-<max> <min>-<max> <dark_gray>(price, then count)");
            plugin.msg(s, "<gray>/market remove <item>  |  /market reroll  |  /market reload");
        }
    }

    /** /market set price|items <item> <min>-<max>   (also /market price|items <item> <range>) */
    private void setRange(CommandSender s, String kind, String target, String rangeText) {
        String k = kind.toLowerCase(Locale.ROOT);
        boolean price;
        if (k.equals("price")) {
            price = true;
        } else if (k.equals("items") || k.equals("count") || k.equals("amount")) {
            price = false;
        } else {
            plugin.msg(s, "<red>Use <white>price</white> or <white>items</white>: "
                    + "/market set price <item> 12-30");
            return;
        }
        Entry e = plugin.find(target);
        if (e == null) {
            plugin.msg(s, "<red>'" + target + "' isn't in the market. Add it with "
                    + "<white>/market add <item> <price> <count></white>.");
            return;
        }
        Range r = validRange(s, rangeText);
        if (r == null) {
            return;
        }
        plugin.getConfig().set("items." + e.id + (price ? ".price" : ".count"), r.toString());
        plugin.saveConfig();
        plugin.loadSettings();
        plugin.msg(s, "<green>" + MarketPlugin.pretty(e.id) + " " + (price ? "price" : "stock")
                + " is now <white>" + r + "</white>. <gray>It's re-rolled from this range at the next rotation "
                + "(or run /market reroll).");
    }

    /** /market add <item|hand> <price min-max> <count min-max> */
    private void add(CommandSender s, String[] a) {
        if (a.length < 4) {
            plugin.msg(s, "<red>Usage: <white>/market add <item> <min>-<max> <min>-<max></white> "
                    + "<gray>(price range, then item count range)");
            return;
        }
        String itemArg = a[1];
        Material m;
        if (itemArg.equalsIgnoreCase("hand")) {
            if (!(s instanceof Player p)) {
                plugin.msg(s, "<red>'hand' only works for players.");
                return;
            }
            ItemStack held = p.getInventory().getItemInMainHand();
            if (held.getType().isAir()) {
                plugin.msg(s, "<red>Hold the item you want to add.");
                return;
            }
            m = held.getType();
        } else if (itemArg.toLowerCase(Locale.ROOT).matches("books?|enchanted_books?")) {
            m = Material.ENCHANTED_BOOK;
        } else {
            m = Material.matchMaterial(itemArg);
        }
        if (m == null || !m.isItem() || m.isAir()) {
            plugin.msg(s, "<red>'" + itemArg + "' isn't a valid item.");
            return;
        }

        // Accept "12-30 64-200", "12-30, 64-200" and "price 12-30 count 64-200".
        String rest = String.join(" ", Arrays.copyOfRange(a, 2, a.length))
                .replace(",", " ").toLowerCase(Locale.ROOT).trim();
        List<String> tokens = new ArrayList<>();
        for (String t : rest.split("\\s+")) {
            if (!t.isEmpty() && !t.equals("price") && !t.equals("count")
                    && !t.equals("items") && !t.equals("amount")) {
                tokens.add(t);
            }
        }
        if (tokens.size() != 2) {
            plugin.msg(s, "<red>Usage: <white>/market add <item> <min>-<max> <min>-<max></white>");
            return;
        }
        Range price = validRange(s, tokens.get(0));
        if (price == null) {
            return;
        }
        Range count = validRange(s, tokens.get(1));
        if (count == null) {
            return;
        }

        String id = (m == Material.ENCHANTED_BOOK) ? "book" : m.name().toLowerCase(Locale.ROOT);
        boolean existed = plugin.entries.containsKey(id);
        plugin.getConfig().set("items." + id + ".material", m.name());
        plugin.getConfig().set("items." + id + ".price", price.toString());
        plugin.getConfig().set("items." + id + ".count", count.toString());
        plugin.saveConfig();
        plugin.loadSettings();
        plugin.msg(s, "<green>" + (existed ? "Updated " : "Added ") + "<white>" + MarketPlugin.pretty(id)
                + "</white>: price <gold>" + price + "</gold>, count <aqua>" + count
                + "</aqua>. <gray>" + (m == Material.ENCHANTED_BOOK ? "Rolls a random book. " : "")
                + "Shows up from the next rotation.");
    }

    private void remove(CommandSender s, String target) {
        Entry e = plugin.find(target);
        if (e == null) {
            plugin.msg(s, "<red>'" + target + "' isn't in the market.");
            return;
        }
        final String id = e.id;
        plugin.getConfig().set("items." + id, null);
        plugin.saveConfig();
        plugin.loadSettings();
        plugin.offers.removeIf(o -> o.id.equals(id));
        plugin.saveState();
        plugin.gui.reopenForViewers();
        plugin.msg(s, "<green>Removed <white>" + MarketPlugin.pretty(id) + "</white> from the market.");
    }

    /** Parses a min-max range and enforces 1..MAX_VALUE, telling the sender what went wrong. */
    private Range validRange(CommandSender s, String text) {
        Range r = Range.parse(text);
        if (r == null) {
            plugin.msg(s, "<red>'" + text + "' isn't a valid range. Use something like <white>12-30</white>.");
            return null;
        }
        if (r.min() < 1 || r.max() > MAX_VALUE) {
            plugin.msg(s, "<red>Ranges must stay between 1 and " + MAX_VALUE + ".");
            return null;
        }
        return r;
    }

    // ───────────────────────── tab completion ─────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        boolean admin = s.hasPermission("market.admin");
        if (a.length == 1) {
            return filter(admin
                    ? List.of("open", "info", "list", "set", "items", "price", "add", "remove", "reroll", "reload")
                    : List.of("open", "info", "list"), a[0]);
        }
        if (!admin) {
            return List.of();
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (a.length == 2) {
            switch (sub) {
                case "set":
                    return filter(List.of("price", "items"), a[1]);
                case "price":
                case "items":
                case "remove":
                    return filter(plugin.entries.keySet(), a[1]);
                case "add":
                    return materials(a[1]);
                default:
                    return List.of();
            }
        }
        if (a.length == 3) {
            switch (sub) {
                case "set":
                    return filter(plugin.entries.keySet(), a[2]);
                case "price":
                case "items":
                    return currentRange(a[1], sub.equals("price"));
                case "add":
                    return List.of("10-25");
                default:
                    return List.of();
            }
        }
        if (a.length == 4) {
            if (sub.equals("set")) {
                return currentRange(a[2], a[1].equalsIgnoreCase("price"));
            }
            if (sub.equals("add")) {
                return List.of("1-64");
            }
        }
        return List.of();
    }

    private List<String> currentRange(String target, boolean price) {
        Entry e = plugin.find(target);
        if (e == null) {
            return List.of();
        }
        return List.of((price ? e.price : e.count).toString());
    }

    private List<String> materials(String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if ("hand".startsWith(p)) {
            out.add("hand");
        }
        for (Material m : Material.values()) {
            if (out.size() >= 40) {
                break;
            }
            String name = m.name().toLowerCase(Locale.ROOT);
            if (m.isItem() && !m.isLegacy() && name.startsWith(p)) {
                out.add(name);
            }
        }
        return out;
    }

    private List<String> filter(Collection<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                out.add(o);
            }
        }
        return out;
    }
}
