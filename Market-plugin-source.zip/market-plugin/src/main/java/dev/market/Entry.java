package dev.market;

import org.bukkit.Material;

/** A line in config.yml: something the market can sell, and how its price/stock are rolled. */
public final class Entry {
    public final String id;
    public final Material material;
    public Range price;
    public Range count;
    /** 0 = regular item. Above 0 = rare item that only appears when the dice say so. */
    public double chance;
    /** How many separate listings this entry produces when it is picked. */
    public int offers;

    public Entry(String id, Material material, Range price, Range count, double chance, int offers) {
        this.id = id;
        this.material = material;
        this.price = price;
        this.count = count;
        this.chance = chance;
        this.offers = offers;
    }

    public boolean isBook() {
        return material == Material.ENCHANTED_BOOK;
    }

    public boolean isRare() {
        return chance > 0;
    }
}
