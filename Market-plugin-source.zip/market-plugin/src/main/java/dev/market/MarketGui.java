package dev.market;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static dev.market.MarketPlugin.c;
import static dev.market.MarketPlugin.lc;

/** The chest-style shop window, its live countdown, and click-to-buy handling. */
public final class MarketGui implements Listener {

    static final class Holder implements InventoryHolder {
        Inventory inv;
        int rows;
        final Map<Integer, Offer> slots = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final MarketPlugin plugin;

    MarketGui(MarketPlugin plugin) {
        this.plugin = plugin;
    }

    // ───────────────────────── opening / rendering ─────────────────────────

    void open(Player p, boolean sound) {
        int n = Math.min(plugin.offers.size(), 28);
        int innerRows = Math.max(1, (n + 6) / 7);
        int rows = Math.min(6, innerRows + 2);

        Holder h = new Holder();
        h.rows = rows;
        h.inv = Bukkit.createInventory(h, rows * 9,
                c("<gradient:#ffb347:#ffd166><bold>✦ Market ✦</bold></gradient>"));
        render(h);
        p.openInventory(h.inv);
        if (sound) {
            p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.6f, 1.2f);
        }
    }

    private void render(Holder h) {
        Inventory inv = h.inv;
        inv.clear();
        h.slots.clear();
        int rows = h.rows;

        ItemStack pane = filler(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = filler(Material.ORANGE_STAINED_GLASS_PANE);
        for (int i = 0; i < rows * 9; i++) {
            int r = i / 9;
            int col = i % 9;
            boolean edgeRow = (r == 0 || r == rows - 1);
            boolean border = edgeRow || col == 0 || col == 8;
            if (border) {
                boolean corner = edgeRow && (col == 0 || col == 8);
                inv.setItem(i, corner ? accent : pane);
            }
        }

        List<Offer> offers = plugin.offers;
        int n = Math.min(offers.size(), 7 * (rows - 2));
        int idx = 0;
        for (int r = 1; r <= rows - 2 && idx < n; r++) {
            int inRow = Math.min(7, n - idx);
            int start = 1 + (7 - inRow) / 2; // centre short rows
            for (int k = 0; k < inRow; k++) {
                int slot = r * 9 + start + k;
                Offer o = offers.get(idx++);
                inv.setItem(slot, display(o));
                h.slots.put(slot, o);
            }
        }
        inv.setItem((rows - 1) * 9 + 4, clock());
    }

    private ItemStack filler(Material m) {
        ItemStack s = new ItemStack(m);
        ItemMeta meta = s.getItemMeta();
        meta.displayName(Component.text(" "));
        s.setItemMeta(meta);
        return s;
    }

    private ItemStack display(Offer o) {
        ItemStack s = o.item.clone();
        s.setAmount(Math.max(1, Math.min(o.stock, s.getMaxStackSize())));
        ItemMeta meta = s.getItemMeta();

        List<Component> lore = new ArrayList<>();
        List<Component> existing = meta.lore();
        if (existing != null) {
            lore.addAll(existing);
        }
        String cur = MarketPlugin.prettyItem(plugin.currency);
        if (o.rare) {
            lore.add(lc("<light_purple><bold>★ RARE FIND"));
        }
        lore.add(Component.empty());
        lore.add(lc("<gray>Price: <gold>" + o.price + "x " + cur + "<dark_gray> each"));
        if (o.stock > 0) {
            lore.add(lc("<gray>In stock: <green>" + o.stock));
            lore.add(Component.empty());
            lore.add(lc("<yellow>Left-click <dark_gray>» <gray>buy 1"));
            lore.add(lc("<yellow>Right-click <dark_gray>» <gray>buy 16"));
            lore.add(lc("<yellow>Shift-click <dark_gray>» <gray>buy 64"));
        } else {
            lore.add(lc("<red><bold>SOLD OUT"));
        }
        meta.lore(lore);
        if (o.rare) {
            meta.setEnchantmentGlintOverride(true);
        }
        s.setItemMeta(meta);
        return s;
    }

    private ItemStack clock() {
        ItemStack s = new ItemStack(Material.CLOCK);
        ItemMeta meta = s.getItemMeta();
        long left = plugin.nextRotation - System.currentTimeMillis();
        meta.displayName(lc("<yellow>Next rotation in <white>" + MarketPlugin.fmtTime(left)));
        List<Component> lore = new ArrayList<>();
        lore.add(lc("<gray>Stock and prices change every <white>"
                + plugin.rotationMinutes + " minutes"));
        lore.add(lc("<gray>Paying with: <gold>" + MarketPlugin.prettyItem(plugin.currency)));
        meta.lore(lore);
        s.setItemMeta(meta);
        return s;
    }

    // ───────────────────────── viewers ─────────────────────────

    private Holder holderOf(Player p) {
        Inventory top = p.getOpenInventory().getTopInventory();
        return top.getHolder() instanceof Holder h ? h : null;
    }

    private List<Player> viewers() {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (holderOf(p) != null) {
                list.add(p);
            }
        }
        return list;
    }

    /** Called every second: keeps the countdown clock ticking for anyone with the shop open. */
    void tickTimers() {
        for (Player p : viewers()) {
            Holder h = holderOf(p);
            if (h != null) {
                h.inv.setItem((h.rows - 1) * 9 + 4, clock());
            }
        }
    }

    void refreshViewers() {
        for (Player p : viewers()) {
            Holder h = holderOf(p);
            if (h != null) {
                render(h);
            }
        }
    }

    /** New stock may need a different window size, so rebuild it for everyone watching. */
    void reopenForViewers() {
        for (Player p : viewers()) {
            open(p, false);
        }
    }

    void closeAll() {
        for (Player p : viewers()) {
            p.closeInventory();
        }
    }

    // ───────────────────────── clicks ─────────────────────────

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) {
            return;
        }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) {
            return;
        }
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) {
            return;
        }
        Offer o = h.slots.get(e.getRawSlot());
        if (o == null) {
            return;
        }
        int amount;
        switch (e.getClick()) {
            case LEFT -> amount = 1;
            case RIGHT -> amount = 16;
            case SHIFT_LEFT, SHIFT_RIGHT -> amount = 64;
            default -> amount = 0;
        }
        if (amount > 0) {
            buy(p, o, amount);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) {
            e.setCancelled(true);
        }
    }

    // ───────────────────────── buying ─────────────────────────

    private void buy(Player p, Offer o, int want) {
        if (!p.hasPermission("market.use")) {
            plugin.msg(p, "<red>You don't have permission to use the market.");
            return;
        }
        if (!plugin.offers.contains(o)) { // the shop rotated while the window was open
            p.closeInventory();
            return;
        }
        String cur = MarketPlugin.prettyItem(plugin.currency);
        if (o.stock <= 0) {
            plugin.msg(p, "<red>That item is sold out.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.0f);
            return;
        }

        int afford = countCurrency(p) / o.price;
        if (afford <= 0) {
            plugin.msg(p, "<red>You need <gold>" + o.price + "x " + cur
                    + "</gold> for one of those.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.0f);
            return;
        }

        int amount = Math.min(Math.min(want, o.stock), afford);
        int cost = amount * o.price;
        removeCurrency(p, cost);
        give(p, o.item, amount);
        o.stock -= amount;
        plugin.saveState();

        plugin.msg(p, "<green>Bought <white>" + amount + "x " + MarketPlugin.describe(o.item)
                + "</white> for <gold>" + cost + "x " + cur + "</gold>.");
        p.playSound(p.getLocation(),
                o.rare ? Sound.ENTITY_PLAYER_LEVELUP : Sound.ENTITY_EXPERIENCE_ORB_PICKUP,
                0.8f, o.rare ? 1.0f : 1.4f);
        refreshViewers();
    }

    private boolean isCurrency(ItemStack s) {
        return s != null && s.getType() == plugin.currency && !s.hasItemMeta();
    }

    private int countCurrency(Player p) {
        int total = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (isCurrency(s)) {
                total += s.getAmount();
            }
        }
        return total;
    }

    private void removeCurrency(Player p, int cost) {
        int remaining = cost;
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack s = contents[i];
            if (!isCurrency(s)) {
                continue;
            }
            int take = Math.min(remaining, s.getAmount());
            remaining -= take;
            if (take == s.getAmount()) {
                contents[i] = null;
            } else {
                s.setAmount(s.getAmount() - take);
            }
        }
        p.getInventory().setStorageContents(contents);
    }

    private void give(Player p, ItemStack template, int amount) {
        int left = amount;
        int max = Math.max(1, template.getMaxStackSize());
        while (left > 0) {
            int n = Math.min(left, max);
            ItemStack stack = template.clone();
            stack.setAmount(n);
            Map<Integer, ItemStack> overflow = p.getInventory().addItem(stack);
            for (ItemStack extra : overflow.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), extra);
            }
            left -= n;
        }
    }
}
