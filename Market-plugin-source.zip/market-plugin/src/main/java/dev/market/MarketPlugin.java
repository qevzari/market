package dev.market;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public final class MarketPlugin extends JavaPlugin {

    static final MiniMessage MM = MiniMessage.miniMessage();
    static final String PREFIX =
            "<gradient:#ffb347:#ffd166><bold>Market</bold></gradient> <dark_gray>»</dark_gray> ";

    private static final Map<String, String> ALIASES = new HashMap<>();

    static {
        ALIASES.put("books", "book");
        ALIASES.put("enchanted_book", "book");
        ALIASES.put("enchanted_books", "book");
        ALIASES.put("nametag", "name_tag");
        ALIASES.put("nametags", "name_tag");
        ALIASES.put("gapple", "golden_apple");
        ALIASES.put("gapples", "golden_apple");
        ALIASES.put("egap", "enchanted_golden_apple");
        ALIASES.put("notch_apple", "enchanted_golden_apple");
        ALIASES.put("netherite", "netherite_ingot");
        ALIASES.put("bottle", "glass_bottle");
        ALIASES.put("bottles", "glass_bottle");
        ALIASES.put("pearl", "ender_pearl");
        ALIASES.put("pearls", "ender_pearl");
    }

    final Map<String, Entry> entries = new LinkedHashMap<>();
    final List<Offer> offers = new ArrayList<>();
    final Random rnd = new Random();

    Material currency = Material.EMERALD;
    int rotationMinutes = 30;
    int regularSlots = 8;
    boolean announceRotation = true;
    long nextRotation;

    MarketGui gui;
    private File dataFile;

    // ───────────────────────── lifecycle ─────────────────────────

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        loadSettings();

        gui = new MarketGui(this);
        getServer().getPluginManager().registerEvents(gui, this);

        MarketCommand command = new MarketCommand(this);
        PluginCommand pc = getCommand("market");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }

        loadState();
        if (offers.isEmpty() || System.currentTimeMillis() >= nextRotation) {
            rotate(false);
        }

        getServer().getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        getLogger().info("Market ready - " + entries.size() + " items, rotating every "
                + rotationMinutes + " minutes.");
    }

    @Override
    public void onDisable() {
        if (gui != null) {
            gui.closeAll();
        }
        saveState();
    }

    private void tick() {
        if (System.currentTimeMillis() >= nextRotation) {
            rotate(true);
        } else {
            gui.tickTimers();
        }
    }

    // ───────────────────────── config ─────────────────────────

    void loadSettings() {
        reloadConfig();
        FileConfiguration cfg = getConfig();

        rotationMinutes = Math.max(1, cfg.getInt("rotation-minutes", 30));
        regularSlots = Math.max(0, cfg.getInt("regular-slots", 8));
        announceRotation = cfg.getBoolean("announce-rotation", true);

        Material cur = Material.matchMaterial(cfg.getString("currency", "EMERALD"));
        currency = (cur != null && cur.isItem()) ? cur : Material.EMERALD;

        entries.clear();
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) {
            return;
        }
        for (String id : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(id);
            if (s == null) {
                continue;
            }
            Material m = Material.matchMaterial(s.getString("material", id));
            if (m == null || !m.isItem() || m.isAir()) {
                getLogger().warning("items." + id + ": unknown material, skipping.");
                continue;
            }
            Range price = Range.parse(s.getString("price"));
            if (price == null || price.min() < 1) {
                getLogger().warning("items." + id + ": bad price range, using 1-1.");
                price = new Range(1, 1);
            }
            Range count = Range.parse(s.getString("count"));
            if (count == null || count.min() < 1) {
                getLogger().warning("items." + id + ": bad count range, using 1-1.");
                count = new Range(1, 1);
            }
            double chance = Math.max(0.0, Math.min(1.0, s.getDouble("chance", 0.0)));
            int offerCount = Math.max(1, s.getInt("offers", 1));
            String key = id.toLowerCase(Locale.ROOT);
            entries.put(key, new Entry(key, m, price, count, chance, offerCount));
        }
    }

    /** Finds an entry by id, tolerating spaces, plurals and a few nicknames. */
    Entry find(String raw) {
        String k = raw.toLowerCase(Locale.ROOT)
                .replace("minecraft:", "")
                .replace(' ', '_')
                .replace('-', '_');
        String alias = ALIASES.get(k);
        if (alias != null) {
            k = alias;
        }
        Entry e = entries.get(k);
        if (e != null) {
            return e;
        }
        if (k.endsWith("s")) {
            return entries.get(k.substring(0, k.length() - 1));
        }
        return null;
    }

    // ───────────────────────── rotation ─────────────────────────

    void rotate(boolean announce) {
        List<Entry> regular = new ArrayList<>();
        List<Entry> rare = new ArrayList<>();
        for (Entry e : entries.values()) {
            if (e.isRare()) {
                rare.add(e);
            } else {
                regular.add(e);
            }
        }

        Collections.shuffle(regular, rnd);
        int take = regularSlots == 0 ? regular.size() : Math.min(regularSlots, regular.size());

        List<Offer> next = new ArrayList<>();
        for (int i = 0; i < take; i++) {
            Entry e = regular.get(i);
            for (int k = 0; k < e.offers; k++) {
                next.add(createOffer(e, false));
            }
        }
        for (Entry e : rare) {
            if (rnd.nextDouble() < e.chance) {
                for (int k = 0; k < e.offers; k++) {
                    next.add(createOffer(e, true));
                }
            }
        }

        offers.clear();
        offers.addAll(next);
        nextRotation = System.currentTimeMillis() + rotationMinutes * 60_000L;
        saveState();
        gui.reopenForViewers();

        if (announce && announceRotation) {
            getServer().broadcast(c(PREFIX + "<yellow>The market just restocked! "
                    + "<gray>Type <white>/market</white> to browse."));
            for (Offer o : offers) {
                if (o.rare) {
                    getServer().broadcast(c(PREFIX + "<light_purple>★ Rare find: <white>"
                            + describe(o.item) + "</white> <gray>(" + o.stock + " in stock)"));
                }
            }
        }
    }

    private Offer createOffer(Entry e, boolean rare) {
        ItemStack stack = e.isBook() ? makeBook() : new ItemStack(e.material);
        stack.setAmount(1);
        return new Offer(e.id, stack, e.price.roll(), e.count.roll(), rare);
    }

    private ItemStack makeBook() {
        List<String> pool = getConfig().getStringList("book-pool");
        for (int tries = 0; tries < 30 && !pool.isEmpty(); tries++) {
            String[] p = pool.get(rnd.nextInt(pool.size())).split("=");
            if (p.length != 2) {
                continue;
            }
            int max;
            try {
                max = Integer.parseInt(p[1].trim());
            } catch (NumberFormatException ex) {
                continue;
            }
            if (max < 1) {
                continue;
            }
            Enchantment ench = Registry.ENCHANTMENT.get(
                    NamespacedKey.minecraft(p[0].trim().toLowerCase(Locale.ROOT)));
            if (ench == null) {
                continue; // not on this server version
            }
            ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
            EnchantmentStorageMeta meta = (EnchantmentStorageMeta) book.getItemMeta();
            if (!meta.addStoredEnchant(ench, 1 + rnd.nextInt(max), false)) {
                continue;
            }
            book.setItemMeta(meta);
            return book;
        }
        getLogger().warning("book-pool produced no usable enchantment - selling a plain book.");
        return new ItemStack(Material.BOOK);
    }

    // ───────────────────────── persistence ─────────────────────────

    void saveState() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-rotation", nextRotation);
        for (int i = 0; i < offers.size(); i++) {
            Offer o = offers.get(i);
            String p = "offers." + i;
            y.set(p + ".id", o.id);
            y.set(p + ".item", o.item);
            y.set(p + ".price", o.price);
            y.set(p + ".stock", o.stock);
            y.set(p + ".rare", o.rare);
        }
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save data.yml: " + ex.getMessage());
        }
    }

    private void loadState() {
        offers.clear();
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        nextRotation = y.getLong("next-rotation", 0L);
        ConfigurationSection sec = y.getConfigurationSection("offers");
        if (sec == null) {
            return;
        }
        List<String> keys = new ArrayList<>(sec.getKeys(false));
        keys.sort(Comparator.comparingInt(Integer::parseInt));
        for (String k : keys) {
            ConfigurationSection o = sec.getConfigurationSection(k);
            if (o == null) {
                continue;
            }
            ItemStack item = o.getItemStack("item");
            if (item == null) {
                continue;
            }
            offers.add(new Offer(
                    o.getString("id", "?"),
                    item,
                    Math.max(1, o.getInt("price", 1)),
                    Math.max(0, o.getInt("stock", 0)),
                    o.getBoolean("rare", false)));
        }
    }

    // ───────────────────────── text helpers ─────────────────────────

    static Component c(String miniMessage) {
        return MM.deserialize(miniMessage);
    }

    /** Lore line: MiniMessage with italics switched off (lore is italic by default). */
    static Component lc(String miniMessage) {
        return MM.deserialize("<!italic>" + miniMessage);
    }

    void msg(CommandSender to, String miniMessage) {
        to.sendMessage(c(PREFIX + miniMessage));
    }

    static String pretty(String raw) {
        if (raw.equalsIgnoreCase("tnt")) {
            return "TNT";
        }
        StringBuilder sb = new StringBuilder();
        for (String w : raw.toLowerCase(Locale.ROOT).split("_")) {
            if (w.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    static String prettyItem(Material m) {
        return pretty(m.name());
    }

    static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return (n >= 0 && n < r.length) ? r[n] : String.valueOf(n);
    }

    /** "Diamond", or "Enchanted Book (Mending)" / "Enchanted Book (Protection IV)". */
    static String describe(ItemStack it) {
        String base = prettyItem(it.getType());
        if (it.getItemMeta() instanceof EnchantmentStorageMeta meta
                && !meta.getStoredEnchants().isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<Enchantment, Integer> en : meta.getStoredEnchants().entrySet()) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(pretty(en.getKey().getKey().getKey()));
                if (en.getKey().getMaxLevel() > 1) {
                    sb.append(' ').append(roman(en.getValue()));
                }
            }
            return base + " (" + sb + ")";
        }
        return base;
    }

    static String fmtTime(long millis) {
        long s = Math.max(0, millis / 1000);
        return (s / 60) + "m " + String.format("%02d", s % 60) + "s";
    }
}
