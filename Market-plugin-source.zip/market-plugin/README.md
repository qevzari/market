# Market

A vanilla-style shop for Paper servers that **restocks and re-rolls its prices every 30 minutes**.
Players pay with a configurable item (emeralds by default), so no economy plugin is needed.

## Build the jar

You need JDK 21 and Maven.

```
mvn clean package
```

The plugin ends up at `target/Market-1.0.0.jar`. Drop it into your server's `plugins/` folder
and restart. Built for Paper 1.21+ (`api-version: 1.21`).

No Maven? Push this folder to a GitHub repo - the included workflow
(`.github/workflows/build.yml`) builds the jar for you; download it from the Actions run's
"Artifacts" section.

## How it works

- Every rotation (30 min by default) the shop picks **8 of the 12 regular items** plus any rare items
  that win their dice roll. Each listing rolls a random **price** and **stock** from its ranges.
- **Netherite Ingot**: 1-in-7.5 chance (13.3%) per rotation, and only **one** is ever in stock.
- **Enchanted Golden Apple**: 1-in-25 chance (4%) per rotation, and only **two** are in stock.
- **Books**: 2 random enchanted books per rotation, drawn from the enchanting-table pool.
  Sharpness V, Efficiency V, Wind Burst and every other table-unavailable enchant are out;
  Mending is in. The pool lives in `config.yml` (`book-pool`) if you want to tweak it.
- Prices are **per single item**. Left-click buys 1, right-click buys 16, shift-click buys 64.
- Rotation timing and stock survive restarts (`plugins/Market/data.yml`).
- The window has a live countdown clock, and the server gets an announcement when the shop
  restocks (with a shout-out for rare finds).

## Commands

| Command | What it does |
|---|---|
| `/market` | Open the shop |
| `/market info` | Time until the next rotation and what's on sale |
| `/market list` | Every item the market can sell, with its ranges |
| `/market set price <item> <min>-<max>` | e.g. `/market set price diamond 12-30` |
| `/market items <item> <min>-<max>` | Stock range, e.g. `/market items diamond 64-200` (`/market set items ...` also works) |
| `/market add <item> <min>-<max> <min>-<max>` | Add any item: price range, then count range. `hand` uses the item you're holding |
| `/market remove <item>` | Take an item out of the market |
| `/market reroll` | Force a rotation right now |
| `/market reload` | Reload `config.yml` |

Range changes apply at the **next rotation** (use `/market reroll` to see them immediately).

## Permissions

- `market.use` - open the shop and buy (default: everyone)
- `market.admin` - everything else (default: ops)

## Config

See `plugins/Market/config.yml`: `rotation-minutes`, `currency`, `regular-slots`,
`announce-rotation`, the full item list with price/count ranges, rare-item `chance`, and `book-pool`.
